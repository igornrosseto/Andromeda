local ClubShared =
{
	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(ClubShared);
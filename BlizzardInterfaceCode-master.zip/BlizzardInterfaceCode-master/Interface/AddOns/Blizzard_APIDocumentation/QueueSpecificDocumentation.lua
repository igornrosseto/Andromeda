local QueueSpecific =
{
	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(QueueSpecific);
local TextureShared =
{
	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(TextureShared);
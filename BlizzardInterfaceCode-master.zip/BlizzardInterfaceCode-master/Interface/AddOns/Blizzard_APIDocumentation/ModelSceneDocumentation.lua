local ModelScene =
{
	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(ModelScene);
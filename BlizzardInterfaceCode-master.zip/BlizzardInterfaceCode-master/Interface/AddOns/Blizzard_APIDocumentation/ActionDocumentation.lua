local Action =
{
	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(Action);
local Base =
{
	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(Base);
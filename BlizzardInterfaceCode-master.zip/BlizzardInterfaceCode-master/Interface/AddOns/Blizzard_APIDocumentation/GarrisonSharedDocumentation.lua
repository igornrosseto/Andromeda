local GarrisonShared =
{
	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(GarrisonShared);
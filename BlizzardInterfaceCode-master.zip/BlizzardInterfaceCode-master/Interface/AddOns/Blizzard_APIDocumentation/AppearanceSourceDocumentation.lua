local AppearanceSource =
{
	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(AppearanceSource);
local Time =
{
	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(Time);
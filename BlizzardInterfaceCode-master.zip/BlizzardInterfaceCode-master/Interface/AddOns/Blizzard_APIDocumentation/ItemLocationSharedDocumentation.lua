local ItemLocationShared =
{
	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(ItemLocationShared);
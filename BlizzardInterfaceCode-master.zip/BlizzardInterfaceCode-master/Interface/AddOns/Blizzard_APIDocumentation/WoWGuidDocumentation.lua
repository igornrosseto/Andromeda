local WoWGuid =
{
	Tables =
	{
	},
};

APIDocumentation:AddDocumentationTable(WoWGuid);
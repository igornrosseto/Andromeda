
function CommunitiesGuildFinderFrameFindAGuildButton_OnClick(self)
	ToggleGuildFinder();
end